from django.urls import path
from . import views

urlpatterns = [
    path('',views.home,name='home'),
    path('event_booking/<int:id>',views.event_booking_view,name='bookevent'),
    path('event/edit/<id>',views.event_booking_edit,name='editevent'),
    path('event/delete/<id>',views.event_booking_delete,name='deleteevent'),
    path('event/category',views.category,name='category'),
    path('event/BookedEvents/',views.bookedevents,name='booked'),
]

