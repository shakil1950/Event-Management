from django.contrib import admin
from .models import EvenBooking,EventCategory

# Register your models here.

admin.site.register(EvenBooking)
# admin.site.register(EventCategory)

@admin.register(EventCategory)
class EventCategoryModelAdmin(admin.ModelAdmin):
    list_display=['id','category','limit']