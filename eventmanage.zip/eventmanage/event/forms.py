from .models import EvenBooking,EventCategory
from django import forms

class EventBookingForm(forms.ModelForm):
    class Meta:
        model=EvenBooking
        fields=['name','description','location','startdate','enddate']
        labels={
            "name":"Event Name",
            "description":"Description",
            "location":"Location",
            "startdate":"Start Date",
            "enddate":"End Date"
        }
        widgets={
            'startdate':forms.DateTimeInput(attrs={
                'type':'date'
            }),
              'enddate':forms.DateTimeInput(attrs={
                  'type':'date'
              })
        }
    
class EventCategoryForm(forms.ModelForm):
    class Meta:
        model=EventCategory
        fields=['category']

