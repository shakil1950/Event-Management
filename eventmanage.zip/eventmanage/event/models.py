from django.db import models
from django.contrib.auth.models import User

# Create your models here.


class EventCategory(models.Model):
    category=models.CharField(max_length=50)
    limit=models.IntegerField()

    def __str__(self):
        return self.category

class EvenBooking(models.Model):
    user=models.ForeignKey(User,on_delete=models.SET_NULL,null=True)
    category=models.ForeignKey(EventCategory,on_delete=models.SET_NULL,null=True)
    name=models.CharField(max_length=150)
    eventid=models.CharField(max_length=200,unique=True)
    description=models.TextField(max_length=400)
    location=models.CharField(max_length=50)
    create=models.DateTimeField(auto_now_add=True)
    update=models.DateTimeField(auto_now=True)
    startdate=models.DateTimeField()
    enddate=models.DateTimeField()
    duration=models.CharField(max_length=30,blank=True,null=True)

    def __str__(self):
        return self.name



