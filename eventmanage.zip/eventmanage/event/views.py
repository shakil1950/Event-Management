from django.shortcuts import render,redirect
from .forms import EventBookingForm,EventCategoryForm
from .models import EvenBooking,EventCategory
from accounts.models import Profile
from django.db.models import Q,Count
import random
from datetime import datetime,date
from django.contrib import messages
from django.contrib.auth.decorators import login_required

# Create your views here.

def home(request):
    
    search=request.GET.get('search') if request.GET.get('search')!=None else ""
    data=EvenBooking.objects.filter(Q(name__icontains=search)|
                                    Q(category__category__icontains=search)|
                                    Q(startdate__icontains=search)|
                                    Q(create__icontains=search)|
                                    Q(description__icontains=search))
    data_upcoming=data.filter(startdate__gt=date.today())
    data_ruunning=data.filter(startdate__lte=date.today(),enddate__gte=date.today())
    data_finished=data.filter(enddate__lte=date.today())
    tota_user=len(Profile.objects.all())
    data_upcoming_count=len(data_upcoming)
    data_ruunning_count=len(data_ruunning)
    data_finished_count=len(data_finished)
    category_data=EventCategory.objects.all()
    context={
        'data':data,
        'data_upcoming':data_upcoming,
        'data_finished':data_finished,
        'data_finished_count':data_finished_count,
        'data_ruunning':data_ruunning,
        'data_ruunning_count':data_ruunning_count,
        'data_upcoming_count':data_upcoming_count,
        'tota_user':tota_user,
        'category_data':category_data
     
    }
    return render(request,'event/home.html',context)

def eventID(user):
    
    ID=str(user.username)+str(datetime.now().date().strftime("%Y%m%d"))+str(random.randrange(1,999))
    return ID

@login_required
def event_booking_view(request,id):
    if request.user.is_superuser==False:
        if request.user.profile.active==False:
            messages.info(request,"You need to update your profile before booking")
            return redirect('profileedit',request.user.profile.id)
    form=EventBookingForm()
    try:
        if request.method=='POST':
            form=EventBookingForm(request.POST)
            if form.is_valid():
                event_obj=form.save(commit=False)
                event_obj.category_id=id
                event_obj.eventid=eventID(request.user)
                event_obj.user=request.user
                event_obj.duration=(event_obj.enddate-event_obj.startdate)
                if event_obj.startdate.date()<date.today():
                    messages.error(request,"Start Date can't be backdate")
                    raise ValueError("Start Date can't be backdate")
                if event_obj.startdate>event_obj.enddate:
                    messages.error(request,"Start Date can't be less gsater than end date")

                    raise ValueError("Start Date can't be less gsater than end date")
                cate=EventCategory.objects.get(category=event_obj.category)
                if cate.limit<1:
                    messages.error(request,"Not available at this moment")
                    raise ValueError("Not available at this moment")
                else:
                    event_obj.save()
                    cate.limit=cate.limit-1
                    cate.save()
                
                messages.success(request,"Booking Successfully")
                form=EventBookingForm()
                return redirect('home')
            else:
                return redirect("bookevent",request.id)
                
        context={
            'form':form
        }
        return render(request,'event/event_booking_form.html',context)
    except ValueError:
        return redirect('bookevent',id)
    except EventCategory.DoesNotExist:
        messages.error(request,"Event category Doedoesn'tnot exist")
        return redirect('category')

@login_required
def event_booking_edit(request,id):
    try:
        data=EvenBooking.objects.get(eventid=id)
        form=EventBookingForm(instance=data)
        if request.method=="POST":
            form=EventBookingForm(request.POST,request.FILES,instance=data)
            if form.is_valid():
                edit_obj=form.save(commit=False)
                edit_obj.duration=(edit_obj.enddate-edit_obj.startdate)
                if edit_obj.startdate.date()<date.today():
                    messages.error(request,"Start Date can't be backdate")
                    raise ValueError("Start Date can't be backdate")
                if edit_obj.startdate>edit_obj.enddate:
                    messages.error(request,"Start Date can't be less gsater than end date")

                    raise ValueError("Start Date can't be less gsater than end date")
                
                edit_obj.save()
                messages.success(request,"Update Successfully")
                return redirect("home")
            else:
                form=EventBookingForm(instance=data)
                return redirect('editevent')
        
        context={
            'form':form
        }
        return render(request,'event/event_booking_form.html',context)
    except ValueError:
        return redirect('home')
    except EvenBooking.DoesNotExist:
        messages.error("Event doesn't exist")
        return redirect('home')

@login_required
def event_booking_delete(request,id):
    try:
        data=EvenBooking.objects.get(eventid=id)
        data.category.limit=data.category.limit+1
        data.category.save()
        data.delete()
        return redirect("home")
    except:
        messages.error(request,"Data Not Found")
        return redirect("home")

@login_required   
def category(request):
    try:
        search=request.GET.get('filter') if request.GET.get('filter')!=None else ""
        print(search)
        all_category=EventCategory.objects.filter(Q(category__icontains=search))
        
        context={
            'data':all_category,
        
        }

        return render(request,'event/category.html',context)
    except EventCategory.DoesNotExist:
        messages.error(request,"Event category Doedoesn'tnot exist")
        return redirect('category')

@login_required
def bookedevents(request):
    data=EvenBooking.objects.filter(user=request.user)
    count_total=len(data)
    print(count_total)
    context={
        'data':data,
        'count_total':count_total
    }
    return render(request,'event/bookedevents.html',context)
