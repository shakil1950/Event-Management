from typing import Any
from django.db import models
from django.contrib.auth.models import User

# Create your models here.

GENDER={
    'male':'Male',
    'female':'Female',
    "other's":'Other'
}
class Profile(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    first_name=models.CharField(max_length=20,blank=True,null=True)
    last_name=models.CharField(max_length=20,blank=True,null=True)
    phone=models.CharField(max_length=14,blank=True,null=True)
    address=models.TextField(max_length=250,blank=True,null=True)
    bio=models.TextField(max_length=200,blank=True,null=True)
    create=models.DateTimeField(auto_now_add=True)
    update=models.DateTimeField(auto_now=True)
    gender=models.CharField(max_length=30,choices=GENDER,blank=True,null=True)
    pic=models.ImageField(upload_to='Profile Image',default='')
    active=models.BooleanField(default=False)


    def __str__(self):
        return self.user.username
    





