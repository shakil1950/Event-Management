from django.shortcuts import render,redirect
from .forms import RegisterForm,LoginForm,ProfileForm
from django.contrib.auth import login,logout,authenticate
from .models import Profile
from event.models import EvenBooking
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User

# Create your views here.




def register_view(request):
    try:
        form=RegisterForm()
        page='registerpage'
        if request.method=="POST":
            form=RegisterForm(request.POST)
            if form.is_valid():
                form.save()
                form=RegisterForm()
                messages.success(request,"User created successfully!! Try to login")
                return redirect('login')
            else:
                messages.error(request,"Something Error")
                return redirect('register')
        context={
            'form':form,
            'page':page
        }
        return render(request,'accounts/login_or_register.html',context)
    except Exception:
        
        return redirect('register')
def login_view(request):
    form=LoginForm()
    page='loginpage'
    if request.user.is_authenticated:
        return redirect("home")
    if request.method=='POST':
        form=LoginForm(data=request.POST)
        if form.is_valid():
            user=form.get_user()
            login(request,user)
            
            if  request.user.is_superuser:
                messages.success(request,"Login Successfull ✌️")
                return redirect("home")
            if user.profile.active:
                messages.success(request,"Login Successfull ✌️")

                return redirect('home')
            else:
                messages.success(request,"Login Successfull ! Please complete your profile before book an event ✔️")
                return redirect("profileedit",user.profile.id)
        else:
            messages.error(request,'invalid userid and password 😔')
            form=LoginForm()
            return redirect('login')
            
    context={
        'form':form,
        'page':page
    }
    return render(request,'accounts/login_or_register.html',context)
@login_required
def logout_view(request):
    logout(request)
    messages.info(request,'Thanks for being with us🩷')
    return redirect('login')

@login_required
def profile_edit_view(request,id):
    profile=Profile.objects.get(id=id)
    form=ProfileForm(instance=profile)
    if request.method=='POST':
        form=ProfileForm(request.POST,request.FILES,instance=profile)
        if form.is_valid():
            profile.active=True
            profile.save()
            form.save()
            messages.success(request,"Successfull!!✌️")
            
            return redirect('home')
            
        else:
            form=ProfileForm(instance=profile)
            return redirect('profileedit')
        
    
    context={
        'form':form
    }

    return render(request,'accounts/profile_create_edit.html',context)
@login_required
def profile_view(request,id):
    try:
        data=Profile.objects.get(id=id)

        context={
            'data':data
        }
        return render(request,'accounts/profile.html',context)
    except Profile.DoesNotExist:
        messages.error(request,"Profile Not Found")
        return redirect('home')