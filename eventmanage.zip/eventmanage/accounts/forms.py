from django import forms
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm
from django.contrib.auth.models import User
from .models import Profile


class RegisterForm(UserCreationForm):
    # class Meta:
    #     model= User
    #     # fields ="__all__"
    #     fields="__all__"
    
    pass
class LoginForm(AuthenticationForm):
    pass

class ProfileForm(forms.ModelForm):
    class Meta:
        model=Profile
        fields=['first_name','last_name','phone','address','bio','gender','pic']
        labels={
            "first_name":" First Name",
            "last_name":"Last Name",
            "phone":"Phone",
            "address":"Address",
            "bio":"Bio",
            "gender":"Gender",
            "pic":"Profile Image"
        }
        widgets={
            'address':forms.TextInput(),
            'bio':forms.TextInput()
        }